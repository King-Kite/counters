import React, { useState } from "react";

const useMyAnimatedCounter = (minValue, maxValue, initValue) => {
	const [count, setCount] = useState(initValue);

	const handleIncrement = () => {
		if (count >= minValue && count < maxValue) return setCount(count + 1);
	};

	const handleDecrement = () => {
		if (count > minValue && count <= maxValue) return setCount(count - 1);
	};

	const handleReset = () => {
		return setCount(initValue);
	};

	return {
		count,
		handleDecrement,
		handleIncrement,
		handleReset
	};
};

export default useMyAnimatedCounter;
