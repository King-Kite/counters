import React from "react";
import useMyAnimatedCounter from "../hooks/useMyAnimatedCounter";

const ThumbsUp = () => {
	const initValue = 37;
	const minValue = 0;
	const maxValue = 100;

	const {
		count,
		handleDecrement,
		handleIncrement,
		handleReset,
	} = useMyAnimatedCounter(minValue, maxValue, initValue);

	return (
		<div className="rounded-lg mx-4 pb-4">
			<div className="flex flex-col rounded-lg">
				<div className="flex flex-col h-full rounded-lg justify-center items-center">
					<h4
						className="text-gray-800 text-3xl text-center font-semibold"
					>
						{count}
					</h4>
					<div onClick={handleIncrement} className="bg-blue-600 cursor-pointer hover:bg-blue-500 rounded-lg p-0 px-1">
						<span className="text-center text-white" style={{ fontSize: "8rem" }}>
							<i className="fas fa-thumbs-up"></i>
						</span>
					</div>
				</div>
				<div className="flex rounded-lg justify-around items-end">
					<span
						onClick={handleDecrement}
						className="bg-gray-100 hover:bg-blue-500 hover:text-gray-100 text-lg cursor-pointer border-2 hover:border-3 border-blue-500 text-blue-500 p-2 py-1 m-3 rounded-full"
					>
						<i className="fas fa-minus"></i>
					</span>
					<span
						onClick={handleReset}
						className="bg-gray-100 hover:bg-red-500 hover:text-gray-100 text-lg cursor-pointer border-2 hover:border-3 border-red-500 text-red-600 p-2 py-1 m-3 rounded-lg"
					>
						<i className="fas fa-square"></i>
					</span>
				</div>
			</div>
		</div>
	);
};

export default ThumbsUp;
