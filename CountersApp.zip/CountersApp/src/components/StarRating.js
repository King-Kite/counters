import React, { useState } from "react";
import useMyAnimatedCounter from "../hooks/useMyAnimatedCounter";

const StarRating = () => {
	const initValue = 3;
	const minValue = 0;
	const maxValue = 20;

	const {
		count,
		handleDecrement,
		handleIncrement,
		handleReset,
	} = useMyAnimatedCounter(minValue, maxValue, initValue);

	const getStars = () => {
		const stars = [];
		for (let i = 0; i < count; i++) {
			stars.push(i);
		}
		return stars;
	};

	const Star = () => (
		<span onClick={handleDecrement} className="text-yellow-600 mx-2">
			<i className="fas fa-star"></i>
		</span>
	);

	const [star, setStar] = useState("far fa-star");

	return (
		<div className="flex justify-between items-center">
			<div
				onClick={handleIncrement}
				onMouseLeave={() => setStar("far fa-star")}
				onMouseOver={() => setStar("fas fa-star")}
				className="cursor-pointer text-gray-600 hover:text-yellow-600"
			>
				<span className="mx-2">
					<i className={star}></i>
				</span>
			</div>
			<div>
				{getStars().map((star) => (
					<Star key={star} />
				))}
			</div>
		</div>
	);
};

export default StarRating;
