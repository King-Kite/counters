import React from "react";
import Counter from "./components/Counter";
import InstagramHeart from "./components/InstagramHeart";
import ProgressRing from "./components/ProgressRing";
import StarRating from "./components/StarRating";
import ThumbsUp from "./components/ThumbsUp";

const App = () => {
  return (
    <div className="flex flex-col">
      <div className="bg-gray-300 rounded-lg m-2 p-3 md:mx-5">
        <StarRating />
      </div>
      <div className="flex flex-col md:flex-row justify-between items-center w-full py-2 md:px-3">
        <div className="bg-gray-300 rounded-lg p-4 m-2 md:px-2 md:mx-1 md:w-2/4">
          <Counter />
        </div>
        <div className="bg-gray-300 rounded-lg p-4 m-2 md:px-2 md:mx-1 md:w-1/4">
          <InstagramHeart />
        </div>
        <div className="bg-gray-300 rounded-lg p-4 m-2 md:px-2 md:mx-1 md:w-1/4">
          <ProgressRing />
        </div>
        <div className="bg-gray-300 rounded-lg p-4 m-2 md:px-2 md:mx-1 md:w-1/4">
          <ThumbsUp />
        </div>
      </div>
    </div>
  )
}

export default App;
